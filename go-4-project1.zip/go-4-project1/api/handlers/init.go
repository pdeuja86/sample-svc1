package handlers

import (
	"net/http"

	"github.com/gorilla/mux"

	domain "github.com/go-4-project1/models"
)

// acc is used to hold the account details
var acc []domain.Account

// Init holds all the exposed api's by this service
func Init() *mux.Router {
	r := mux.NewRouter()
	r.HandleFunc("/v1/create", createHandler).Methods(http.MethodPost)
	r.HandleFunc("/v1/get/{id}", getAccountDetailsHandler).Methods(http.MethodGet)
	r.HandleFunc("/v1/update/{id}", updateAccount).Methods(http.MethodPut)
	r.HandleFunc("/v1/delete/{id}", deleteAccountHandler).Methods(http.MethodDelete)

	http.ListenAndServe(":8080", r)
	return r
}
