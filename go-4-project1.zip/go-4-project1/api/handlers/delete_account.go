package handlers

import (
	"net/http"

	"github.com/go-4-project1/service"
	"github.com/gorilla/mux"
)

func deleteAccountHandler(w http.ResponseWriter, r *http.Request) {

	// capture params passed via URL
	params := mux.Vars(r)

	resp, err := service.DeleteAccount(params["id"])
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		w.Write([]byte("Account not found"))
		return
	}

	w.WriteHeader(http.StatusNoContent)
	w.Write([]byte(resp))
}
