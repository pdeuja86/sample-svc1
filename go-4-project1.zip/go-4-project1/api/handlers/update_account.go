package handlers

import (
	"encoding/json"
	"io/ioutil"
	"net/http"

	domain "github.com/go-4-project1/models"
	"github.com/go-4-project1/service"
	"github.com/gorilla/mux"
)

func updateAccount(w http.ResponseWriter, r *http.Request) {
	// capture the id passed via URI
	params := mux.Vars(r)

	// read the request body
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("Bad request"))
		return
	}

	var account domain.Account

	// Unmarshal the body into variable a
	err = json.Unmarshal(body, &account)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("Bad request"))
		return
	}
	// store the account details into accounts object
	account.ID = params["id"]

	service.UpdateAccount(account)

	w.Write([]byte("Account updated successfully"))
}
