package main

import (
	"github.com/go-4-project1/api/handlers"
)

func main() {
	// initilize api layer
	handlers.Init()
}
