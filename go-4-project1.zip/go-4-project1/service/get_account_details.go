package service

import (
	"github.com/go-4-project1/models"
)

// GetAccounts is used to get the account details
func GetAccounts(id string) models.Account {
	// take all accounts and iterate over the for loop
	for i := range Accounts {
		// check if id passed by the user is matching with any record
		if id == Accounts[i].ID {
			// if account id matched, send the details to user
			return Accounts[i]
		}
	}
	return models.Account{}
}
